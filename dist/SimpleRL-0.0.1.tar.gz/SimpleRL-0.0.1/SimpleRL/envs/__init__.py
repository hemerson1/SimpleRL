from base import environment_base


# LASER TAG ENVIRONMENT
from laser_tag import laser_tag