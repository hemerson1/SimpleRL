
# LASER TAG ENVIRONMENT
from laser_tag_utils import generate_scenario